import React, { useState, useRef } from 'react';
import { 
  SiteConfig, 
  AllowedUser, 
  DossierCard,
  ExamVenue,
  Announcement 
} from '../types/admin';
import { 
  Sliders, 
  Users, 
  LayoutGrid, 
  FileSpreadsheet, 
  Award, 
  Settings, 
  Save, 
  RotateCcw, 
  LogOut, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Eye, 
  Calendar, 
  Upload, 
  Building2,
  Megaphone,
  Edit3,
  X,
  AlertTriangle,
  Info,
  Bell
} from 'lucide-react';
import { saveSiteConfig, resetSiteConfig } from '../utils/appData';
import { toPersianDigits } from '../utils/persianUtils';

interface AdminPanelProps {
  config: SiteConfig;
  onUpdateConfig: (newConfig: SiteConfig) => void;
  onLogoutAdmin: () => void;
  onViewLiveSite: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  config,
  onUpdateConfig,
  onLogoutAdmin,
  onViewLiveSite,
}) => {
  const [formData, setFormData] = useState<SiteConfig>(config);
  const [activeTab, setActiveTab] = useState<'users' | 'announcements' | 'general' | 'cards' | 'exam' | 'venues' | 'grades' | 'ranks'>('users');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // New user form temp state
  const [newUsername, setNewUsername] = useState('');
  const [newNationalId, setNewNationalId] = useState('');

  // Announcement management state
  const [newAnnTitle, setNewAnnTitle] = useState('');
  const [newAnnContent, setNewAnnContent] = useState('');
  const [newAnnDate, setNewAnnDate] = useState('۱۴۰۳/۰۴/۱۸');
  const [newAnnPriority, setNewAnnPriority] = useState<Announcement['priority']>('important');
  const [editingAnnId, setEditingAnnId] = useState<string | null>(null);
  const [editAnnTitle, setEditAnnTitle] = useState('');
  const [editAnnContent, setEditAnnContent] = useState('');
  const [editAnnDate, setEditAnnDate] = useState('');
  const [editAnnPriority, setEditAnnPriority] = useState<Announcement['priority']>('important');

  // New card temp state
  const [newCardTitle, setNewCardTitle] = useState('');
  const [newCardSubtitle, setNewCardSubtitle] = useState('');
  const [newCardIcon, setNewCardIcon] = useState<DossierCard['iconType']>('file-text');

  // New venue temp state
  const [newVenueCity, setNewVenueCity] = useState('');
  const [newVenueTitle, setNewVenueTitle] = useState('');
  const [newVenueCode, setNewVenueCode] = useState('');

  // New grade item temp state
  const [newSubject, setNewSubject] = useState('');
  const [newGrade, setNewGrade] = useState('');

  const cardFileInputRef = useRef<HTMLInputElement>(null);
  const photoFileInputRef = useRef<HTMLInputElement>(null);

  const handleSave = () => {
    saveSiteConfig(formData);
    onUpdateConfig(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleReset = () => {
    if (window.confirm('آیا از بازنشانی کلیه اطلاعات و تنظیمات به مقادیر اولیه اطمینان دارید؟')) {
      const reset = resetSiteConfig();
      setFormData(reset);
      onUpdateConfig(reset);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    }
  };

  // User management
  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim() || !newNationalId.trim()) return;
    const newUser: AllowedUser = {
      id: Date.now().toString(),
      username: newUsername.trim(),
      nationalId: newNationalId.trim(),
      role: 'کاربر مجاز',
      status: 'active',
    };
    setFormData({
      ...formData,
      allowedUsers: [...formData.allowedUsers, newUser],
    });
    setNewUsername('');
    setNewNationalId('');
  };

  const handleDeleteUser = (id: string) => {
    if (formData.allowedUsers.length <= 1) {
      alert('حداقل یک کاربر مجاز باید در سیستم باقی بماند.');
      return;
    }
    setFormData({
      ...formData,
      allowedUsers: formData.allowedUsers.filter((u) => u.id !== id),
    });
  };

  // Announcement management
  const handleAddAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnnTitle.trim() || !newAnnContent.trim()) return;
    const newAnn: Announcement = {
      id: 'ann-' + Date.now(),
      title: newAnnTitle.trim(),
      content: newAnnContent.trim(),
      date: newAnnDate.trim() || '۱۴۰۳/۰۴/۱۸',
      priority: newAnnPriority,
      isActive: true,
    };
    setFormData({
      ...formData,
      announcements: [newAnn, ...(formData.announcements || [])],
    });
    setNewAnnTitle('');
    setNewAnnContent('');
  };

  const handleDeleteAnnouncement = (id: string) => {
    setFormData({
      ...formData,
      announcements: (formData.announcements || []).filter((a) => a.id !== id),
    });
  };

  const handleToggleAnnouncementActive = (id: string) => {
    setFormData({
      ...formData,
      announcements: (formData.announcements || []).map((a) =>
        a.id === id ? { ...a, isActive: !a.isActive } : a
      ),
    });
  };

  const handleStartEditAnnouncement = (ann: Announcement) => {
    setEditingAnnId(ann.id);
    setEditAnnTitle(ann.title);
    setEditAnnContent(ann.content);
    setEditAnnDate(ann.date);
    setEditAnnPriority(ann.priority);
  };

  const handleSaveEditAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAnnId || !editAnnTitle.trim() || !editAnnContent.trim()) return;
    setFormData({
      ...formData,
      announcements: (formData.announcements || []).map((a) =>
        a.id === editingAnnId
          ? {
              ...a,
              title: editAnnTitle.trim(),
              content: editAnnContent.trim(),
              date: editAnnDate.trim() || a.date,
              priority: editAnnPriority,
            }
          : a
      ),
    });
    setEditingAnnId(null);
  };

  // Card management
  const handleAddCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCardTitle.trim()) return;
    const newCard: DossierCard = {
      id: 'card-' + Date.now(),
      title: newCardTitle.trim(),
      subtitle: newCardSubtitle.trim() || 'مدیریت و مشاهده فرآیند',
      iconType: newCardIcon,
      buttonText: 'ورود به بخش',
      isActive: true,
      order: formData.cards.length + 1,
    };
    setFormData({
      ...formData,
      cards: [...formData.cards, newCard],
    });
    setNewCardTitle('');
    setNewCardSubtitle('');
  };

  const handleDeleteCard = (id: string) => {
    setFormData({
      ...formData,
      cards: formData.cards.filter((c) => c.id !== id),
    });
  };

  const handleToggleCardActive = (id: string) => {
    setFormData({
      ...formData,
      cards: formData.cards.map((c) => c.id === id ? { ...c, isActive: !c.isActive } : c),
    });
  };

  // Venue management
  const handleAddVenue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVenueTitle.trim()) return;
    const newV: ExamVenue = {
      id: 'v-' + Date.now(),
      city: newVenueCity.trim() || 'تهران',
      name: `${newVenueCity.trim() ? newVenueCity.trim() + ' - ' : ''}${newVenueTitle.trim()}`,
      code: newVenueCode.trim() || ('V-' + Math.floor(100 + Math.random() * 900)),
    };
    setFormData({
      ...formData,
      venues: [...(formData.venues || []), newV],
    });
    setNewVenueCity('');
    setNewVenueTitle('');
    setNewVenueCode('');
  };

  const handleDeleteVenue = (id: string) => {
    if ((formData.venues || []).length <= 1) {
      alert('حداقل یک حوزه امتحانی باید در سامانه وجود داشته باشد.');
      return;
    }
    setFormData({
      ...formData,
      venues: formData.venues.filter((v) => v.id !== id),
    });
  };

  // Image upload helpers
  const handleExamCardFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setFormData({
        ...formData,
        examCardImage: e.target?.result as string,
      });
    };
    reader.readAsDataURL(file);
  };

  const handlePhotoFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setFormData({
        ...formData,
        candidatePhoto: e.target?.result as string,
      });
    };
    reader.readAsDataURL(file);
  };

  // Grade management
  const handleAddGrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject.trim() || !newGrade.trim()) return;
    setFormData({
      ...formData,
      subjectGrades: [...formData.subjectGrades, { subject: newSubject.trim(), grade: newGrade.trim() }],
    });
    setNewSubject('');
    setNewGrade('');
  };

  const handleDeleteGrade = (index: number) => {
    setFormData({
      ...formData,
      subjectGrades: formData.subjectGrades.filter((_, i) => i !== index),
    });
  };

  return (
    <div className="w-full max-w-5xl mx-auto p-4 sm:p-6" dir="rtl">
      {/* Top Admin Header */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-xl border border-slate-800 mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Sliders className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-black text-white">پنل مدیریت و کنترل جامع سامانه</h1>
              <span className="bg-amber-500/20 text-amber-300 text-[11px] font-bold px-2 py-0.5 rounded-full border border-amber-500/30 font-mono">
                dodozoo
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              آدرس مسیر کنترل: <span className="font-mono text-amber-200">koonik.ir/dodozoo</span>
            </p>
          </div>
        </div>

        {/* Global Actions */}
        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <button
            onClick={handleSave}
            className="flex-1 md:flex-none flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white px-4 py-2 rounded-xl font-bold text-xs transition duration-200 shadow-md cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>ذخیره تغییرات</span>
          </button>

          <button
            onClick={onViewLiveSite}
            className="flex-1 md:flex-none flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 rounded-xl font-bold text-xs transition duration-200 cursor-pointer"
          >
            <Eye className="w-4 h-4" />
            <span>مشاهده زنده سایت</span>
          </button>

          <button
            onClick={handleReset}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition cursor-pointer"
            title="بازنشانی به مقادیر پیش‌فرض"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={onLogoutAdmin}
            className="p-2 bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800/40 rounded-xl transition cursor-pointer"
            title="خروج از مدیریت"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Save Success Alert */}
      {savedSuccess && (
        <div className="mb-6 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 flex items-center gap-2.5 shadow-sm animate-in fade-in duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <div className="text-xs sm:text-sm font-bold">
            تغییرات با موفقیت در کل سامانه ذخیره و اعمال شد!
          </div>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-6 scrollbar-none">
        <button
          onClick={() => setActiveTab('users')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition whitespace-nowrap cursor-pointer ${
            activeTab === 'users'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>کاربران مجاز ({toPersianDigits(formData.allowedUsers.length)})</span>
        </button>

        <button
          onClick={() => setActiveTab('announcements')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition whitespace-nowrap cursor-pointer ${
            activeTab === 'announcements'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Megaphone className="w-4 h-4" />
          <span>اطلاعیه‌ها و پیام‌ها ({toPersianDigits(formData.announcements?.length || 0)})</span>
        </button>

        <button
          onClick={() => setActiveTab('general')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition whitespace-nowrap cursor-pointer ${
            activeTab === 'general'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>عناوین و سربرگ‌ها</span>
        </button>

        <button
          onClick={() => setActiveTab('cards')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition whitespace-nowrap cursor-pointer ${
            activeTab === 'cards'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <LayoutGrid className="w-4 h-4" />
          <span>کارت‌های صفحه پرونده ({toPersianDigits(formData.cards.length)})</span>
        </button>

        <button
          onClick={() => setActiveTab('exam')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition whitespace-nowrap cursor-pointer ${
            activeTab === 'exam'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>کارت آزمون و آپلود تصویر</span>
        </button>

        <button
          onClick={() => setActiveTab('venues')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition whitespace-nowrap cursor-pointer ${
            activeTab === 'venues'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>حوزه‌های آزمون سراسری ({toPersianDigits(formData.venues?.length || 0)})</span>
        </button>

        <button
          onClick={() => setActiveTab('grades')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition whitespace-nowrap cursor-pointer ${
            activeTab === 'grades'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>کارنامه و نمرات نهایی</span>
        </button>

        <button
          onClick={() => setActiveTab('ranks')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition whitespace-nowrap cursor-pointer ${
            activeTab === 'ranks'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>رتبه و تراز کنکور</span>
        </button>
      </div>

      {/* TAB 1: USERS */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h2 className="text-base font-bold text-slate-800 mb-2 flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              <span>مدیریت کاربران دارای مجوز ورود به سامانه</span>
            </h2>
            <p className="text-xs text-slate-500 mb-5">
              تنها افرادی که نام کاربری و کد ملی آن‌ها در این جدول ثبت شود امکان ورود به سامانه را خواهند داشت.
            </p>

            {/* User List */}
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden mb-6">
              {formData.allowedUsers.map((user) => (
                <div key={user.id} className="p-4 bg-white flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-sm">
                      {user.username.charAt(0)}
                    </div>
                    <div>
                      <div className="font-bold text-sm text-slate-800">{user.username}</div>
                      <div className="text-xs text-slate-500 font-mono mt-0.5 flex items-center gap-2">
                        <span>کد ملی:</span>
                        <strong className="text-slate-700">{user.nationalId}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="bg-emerald-50 text-emerald-700 text-xs px-2.5 py-1 rounded-md font-bold">
                      فعال
                    </span>
                    <button
                      onClick={() => handleDeleteUser(user.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                      title="حذف کاربر"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add User Form */}
            <form onSubmit={handleAddUser} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <h3 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-blue-600" />
                <span>افزودن کاربر جدید مجاز</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">نام و نام خانوادگی</label>
                  <input
                    type="text"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    placeholder="مثال: امیرحسین صادقیان"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">کد ملی ۱۰ رقمی</label>
                  <input
                    type="text"
                    value={newNationalId}
                    onChange={(e) => setNewNationalId(e.target.value)}
                    placeholder="مثال: 2960931394"
                    maxLength={10}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono text-left"
                    required
                  />
                </div>
              </div>
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold text-xs transition cursor-pointer"
              >
                ثبت کاربر جدید
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 2: ANNOUNCEMENTS (مدیریت اطلاعیه‌ها و پیام‌ها) */}
      {activeTab === 'announcements' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h2 className="text-base font-bold text-slate-800 mb-2 flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-blue-600" />
              <span>مدیریت اطلاعیه‌ها و پیام‌های صفحه داشبورد کاربری</span>
            </h2>
            <p className="text-xs text-slate-500 mb-5">
              پیام‌ها و اطلاعیه‌های ثبت شده در این بخش بلافاصله پس از ورود کاربر، در کادر اطلاعیه‌های بالای داشبورد نمایش داده خواهند شد.
            </p>

            {/* List of Announcements */}
            <div className="space-y-3 mb-6">
              {(formData.announcements || []).map((ann) => (
                <div 
                  key={ann.id}
                  className="p-4 bg-slate-50 rounded-xl border border-slate-200 transition"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-200/60">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${
                        ann.priority === 'urgent' 
                          ? 'bg-rose-100 text-rose-800 border-rose-200' 
                          : ann.priority === 'important'
                          ? 'bg-amber-100 text-amber-900 border-amber-200'
                          : 'bg-blue-100 text-blue-900 border-blue-200'
                      }`}>
                        {ann.priority === 'urgent' ? 'فوری و مهم' : ann.priority === 'important' ? 'اطلاعیه مهم' : 'عادی'}
                      </span>
                      <strong className="text-sm font-bold text-slate-800">{ann.title}</strong>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-auto">
                      <span className="text-xs text-slate-400 font-mono">{ann.date}</span>

                      <button
                        type="button"
                        onClick={() => handleToggleAnnouncementActive(ann.id)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                          ann.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {ann.isActive ? 'فعال (در حال نمایش)' : 'مخفی'}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleStartEditAnnouncement(ann)}
                        className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition cursor-pointer"
                        title="ویرایش اطلاعیه"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDeleteAnnouncement(ann.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                        title="حذف اطلاعیه"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 mt-2.5 leading-relaxed whitespace-pre-line bg-white/60 p-2.5 rounded-lg border border-slate-200/40">
                    {ann.content}
                  </p>
                </div>
              ))}
            </div>

            {/* Edit Announcement Modal / Box */}
            {editingAnnId && (
              <form onSubmit={handleSaveEditAnnouncement} className="mb-6 p-4 bg-amber-50/80 border border-amber-300 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                    <Edit3 className="w-4 h-4 text-amber-700" />
                    <span>ویرایش اطلاعیه</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => setEditingAnnId(null)}
                    className="p-1 text-amber-800 hover:bg-amber-100 rounded"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">عنوان اطلاعیه</label>
                    <input
                      type="text"
                      value={editAnnTitle}
                      onChange={(e) => setEditAnnTitle(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">اولویت</label>
                    <select
                      value={editAnnPriority}
                      onChange={(e) => setEditAnnPriority(e.target.value as any)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-medium"
                    >
                      <option value="urgent">فوری و مهم (قرمز)</option>
                      <option value="important">اطلاعیه مهم (زرد/نارنجی)</option>
                      <option value="info">اطلاع‌رسانی عمومی (آبی)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">متن کامل اطلاعیه</label>
                  <textarea
                    rows={3}
                    value={editAnnContent}
                    onChange={(e) => setEditAnnContent(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                    required
                  />
                </div>

                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-lg font-bold text-xs transition cursor-pointer"
                  >
                    ذخیره ویرایش اطلاعیه
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingAnnId(null)}
                    className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-3 py-2 rounded-lg text-xs transition cursor-pointer"
                  >
                    انصراف
                  </button>
                </div>
              </form>
            )}

            {/* Add New Announcement Form */}
            <form onSubmit={handleAddAnnouncement} className="bg-blue-50/60 p-4 rounded-xl border border-blue-200/80 space-y-3">
              <h3 className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-blue-600" />
                <span>افزودن اطلاعیه / پیام جدید به داشبورد</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">عنوان پیام / اطلاعیه</label>
                  <input
                    type="text"
                    value={newAnnTitle}
                    onChange={(e) => setNewAnnTitle(e.target.value)}
                    placeholder="مثال: زمان‌بندی دریافت کارت ورود به جلسه"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">اولویت نمایش</label>
                  <select
                    value={newAnnPriority}
                    onChange={(e) => setNewAnnPriority(e.target.value as any)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-medium"
                  >
                    <option value="important">اطلاعیه مهم (زرد/نارنجی)</option>
                    <option value="urgent">فوری و بسیار مهم (قرمز)</option>
                    <option value="info">اطلاع‌رسانی عمومی (آبی)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">متن کامل اطلاعیه</label>
                  <textarea
                    rows={3}
                    value={newAnnContent}
                    onChange={(e) => setNewAnnContent(e.target.value)}
                    placeholder="متن کامل و توضیحات پیام را اینجا بنویسید..."
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">تاریخ درج اطلاعیه</label>
                  <input
                    type="text"
                    value={newAnnDate}
                    onChange={(e) => setNewAnnDate(e.target.value)}
                    placeholder="مثال: ۱۴۰۳/۰۴/۱۸"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono text-center"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold text-xs transition cursor-pointer"
              >
                ثبت و انتشار اطلاعیه در داشبورد
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 3: GENERAL & HEADERS */}
      {activeTab === 'general' && (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-4">
          <h2 className="text-base font-bold text-slate-800 mb-2 flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-600" />
            <span>تنظیمات سربرگ و عناوین صفحه پرونده الکترونیک</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">عنوان اصلی صفحه (رنگ فیروزه‌ای)</label>
              <input
                type="text"
                value={formData.siteTitle}
                onChange={(e) => setFormData({ ...formData, siteTitle: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">متن نشان بیضی‌شکل (بج زیر عنوان)</label>
              <input
                type="text"
                value={formData.badgeText}
                onChange={(e) => setFormData({ ...formData, badgeText: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold text-slate-800"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">توضیحات زیر عنوان</label>
            <input
              type="text"
              value={formData.siteSubtitle}
              onChange={(e) => setFormData({ ...formData, siteSubtitle: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">نسخه سیستم</label>
              <input
                type="text"
                value={formData.version}
                onChange={(e) => setFormData({ ...formData, version: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">پیام امنیتی پاورقی</label>
              <input
                type="text"
                value={formData.securityNotice}
                onChange={(e) => setFormData({ ...formData, securityNotice: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800"
              />
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: CARDS */}
      {activeTab === 'cards' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h2 className="text-base font-bold text-slate-800 mb-2 flex items-center gap-2">
              <LayoutGrid className="w-5 h-5 text-blue-600" />
              <span>مدیریت و ویرایش کارت‌های صفحه پرونده</span>
            </h2>
            <p className="text-xs text-slate-500 mb-5">
              می‌توانید عنوان، توضیحات، آیکون و وضعیت فعال بودن هر کدام از کارت‌ها را تغییر داده یا کارت جدید اضافه کنید.
            </p>

            <div className="space-y-4 mb-6">
              {formData.cards.map((card, idx) => (
                <div key={card.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-xs flex items-center justify-center font-bold">
                        {toPersianDigits(idx + 1)}
                      </span>
                      <input
                        type="text"
                        value={card.title}
                        onChange={(e) => {
                          const updated = [...formData.cards];
                          updated[idx].title = e.target.value;
                          setFormData({ ...formData, cards: updated });
                        }}
                        className="font-bold text-sm text-slate-800 bg-white px-2.5 py-1 rounded-md border border-slate-300"
                      />
                    </div>
                    <div className="mt-2">
                      <input
                        type="text"
                        value={card.subtitle}
                        onChange={(e) => {
                          const updated = [...formData.cards];
                          updated[idx].subtitle = e.target.value;
                          setFormData({ ...formData, cards: updated });
                        }}
                        placeholder="متن توضیحی کارت"
                        className="text-xs text-slate-600 bg-white px-2.5 py-1 rounded-md border border-slate-300 w-full max-w-sm"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleToggleCardActive(card.id)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold cursor-pointer transition ${
                        card.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {card.isActive ? 'نمایش در سایت' : 'مخفی شده'}
                    </button>

                    <button
                      onClick={() => handleDeleteCard(card.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                      title="حذف کارت"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add Card Form */}
            <form onSubmit={handleAddCard} className="bg-blue-50/60 p-4 rounded-xl border border-blue-200/80 space-y-3">
              <h3 className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-blue-600" />
                <span>افزودن کارت / بخش جدید به صفحه</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">عنوان کارت</label>
                  <input
                    type="text"
                    value={newCardTitle}
                    onChange={(e) => setNewCardTitle(e.target.value)}
                    placeholder="مثال: اعلام نتایج نهایی"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">توضیحات کارت</label>
                  <input
                    type="text"
                    value={newCardSubtitle}
                    onChange={(e) => setNewCardSubtitle(e.target.value)}
                    placeholder="مثال: پیگیری پذیرش دانشگاه"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">نوع آیکون</label>
                  <select
                    value={newCardIcon}
                    onChange={(e) => setNewCardIcon(e.target.value as any)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                  >
                    <option value="user-plus">کاربری / ثبت نام</option>
                    <option value="id-card">کارت ورود به جلسه</option>
                    <option value="file-text">کارنامه / پرونده</option>
                    <option value="award">مدال / رتبه</option>
                    <option value="map-pin">حوزه آزمون</option>
                    <option value="school">دانشگاه</option>
                  </select>
                </div>
              </div>
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold text-xs transition cursor-pointer"
              >
                افزودن کارت
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 5: EXAM & PHOTO UPLOAD */}
      {activeTab === 'exam' && (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-6">
          <h2 className="text-base font-bold text-slate-800 mb-2 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-600" />
            <span>ویرایش مشخصات کارت ورود به جلسه و بارگذاری تصاویر کارت/داوطلب</span>
          </h2>

          {/* Image & Photo Upload Section */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200">
            {/* Candidate Photo Upload */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">عکس پرسنلی داوطلب</label>
              <div className="flex items-center gap-3">
                <div className="w-20 h-24 rounded-xl border border-slate-300 overflow-hidden bg-white flex items-center justify-center shadow-xs">
                  {formData.candidatePhoto ? (
                    <img 
                      src={formData.candidatePhoto} 
                      alt="Candidate" 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <span className="text-[10px] text-slate-400 text-center px-1">بدون عکس</span>
                  )}
                </div>
                <div className="space-y-1.5">
                  <input
                    ref={photoFileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && handlePhotoFileUpload(e.target.files[0])}
                  />
                  <button
                    type="button"
                    onClick={() => photoFileInputRef.current?.click()}
                    className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>آپلود عکس داوطلب</span>
                  </button>
                  {formData.candidatePhoto && (
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, candidatePhoto: null })}
                      className="text-[11px] text-rose-600 hover:underline block cursor-pointer"
                    >
                      حذف عکس
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Exam Card Full Image Upload */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">تصویر یا اسکن کامل کارت آزمون (جهت دانلود خودکار)</label>
              <div className="flex items-center gap-3">
                <div className="w-24 h-24 rounded-xl border border-slate-300 overflow-hidden bg-white flex items-center justify-center shadow-xs">
                  {formData.examCardImage ? (
                    <img 
                      src={formData.examCardImage} 
                      alt="Card Scan" 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <span className="text-[10px] text-slate-400 text-center px-1">بدون تصویر کارت</span>
                  )}
                </div>
                <div className="space-y-1.5">
                  <input
                    ref={cardFileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && handleExamCardFileUpload(e.target.files[0])}
                  />
                  <button
                    type="button"
                    onClick={() => cardFileInputRef.current?.click()}
                    className="bg-slate-800 hover:bg-slate-900 text-white text-xs px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>آپلود فایل کارت آزمون</span>
                  </button>
                  {formData.examCardImage && (
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, examCardImage: null })}
                      className="text-[11px] text-rose-600 hover:underline block cursor-pointer"
                    >
                      حذف فایل کارت
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">وضعیت ثبت‌نام</label>
              <input
                type="text"
                value={formData.registrationStatus}
                onChange={(e) => setFormData({ ...formData, registrationStatus: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">گروه آزمایشی</label>
              <input
                type="text"
                value={formData.studyGroup}
                onChange={(e) => setFormData({ ...formData, studyGroup: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">شماره پرونده</label>
              <input
                type="text"
                value={formData.fileNumber}
                onChange={(e) => setFormData({ ...formData, fileNumber: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-mono"
              />
            </div>
          </div>

          <div className="border-t border-slate-100 pt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">تاریخ برگزاری آزمون</label>
              <input
                type="text"
                value={formData.examDate}
                onChange={(e) => setFormData({ ...formData, examDate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">ساعت حضور در حوزه</label>
              <input
                type="text"
                value={formData.arrivalTime}
                onChange={(e) => setFormData({ ...formData, arrivalTime: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">نام حوزه آزمون پیش‌فرض</label>
              <input
                type="text"
                value={formData.examVenue}
                onChange={(e) => setFormData({ ...formData, examVenue: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">سالن و شماره صندلی</label>
              <input
                type="text"
                value={formData.examHall}
                onChange={(e) => setFormData({ ...formData, examHall: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: VENUES (تغییر حوزه آزمون سراسری) */}
      {activeTab === 'venues' && (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-6">
          <h2 className="text-base font-bold text-slate-800 mb-2 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-blue-600" />
            <span>مدیریت و افزودن حوزه‌های آزمون سراسری برای انتخاب داوطلبان</span>
          </h2>
          <p className="text-xs text-slate-500">
            حوزه‌های ثبت شده در این بخش در منوی کشویی کارت ۳ (تغییر حوزه آزمون سراسری) برای انتخاب داوطلب نمایش داده می‌شوند.
          </p>

          {/* Venues List */}
          <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
            {formData.venues && formData.venues.map((venue) => (
              <div key={venue.id} className="p-3.5 bg-white flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-xs text-slate-800">{venue.name}</div>
                    <div className="text-[11px] text-slate-400 font-mono flex items-center gap-2 mt-0.5">
                      <span>شهر: {venue.city}</span>
                      <span>•</span>
                      <span>کد حوزه: {venue.code}</span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleDeleteVenue(venue.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                  title="حذف حوزه"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          {/* Add Venue Form */}
          <form onSubmit={handleAddVenue} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <h3 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Plus className="w-4 h-4 text-blue-600" />
              <span>افزودن حوزه امتحانی جدید</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">شهر حوزه</label>
                <input
                  type="text"
                  value={newVenueCity}
                  onChange={(e) => setNewVenueCity(e.target.value)}
                  placeholder="مثال: تبریز"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                  required
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">عنوان دانشگاه / حوزه</label>
                <input
                  type="text"
                  value={newVenueTitle}
                  onChange={(e) => setNewVenueTitle(e.target.value)}
                  placeholder="مثال: ناحیه ۳ - دانشگاه هنر"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                  required
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">کد اختصاصی حوزه</label>
                <input
                  type="text"
                  value={newVenueCode}
                  onChange={(e) => setNewVenueCode(e.target.value)}
                  placeholder="مثال: TBZ-301"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>
            </div>
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold text-xs transition cursor-pointer"
            >
              افزودن حوزه به سامانه
            </button>
          </form>
        </div>
      )}

      {/* TAB 7: GRADES */}
      {activeTab === 'grades' && (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-5">
          <h2 className="text-base font-bold text-slate-800 mb-2 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-blue-600" />
            <span>ویرایش نمرات امتحانات نهایی و معدل دیپلم</span>
          </h2>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">معدل کتبی نهایی</label>
            <input
              type="text"
              value={formData.finalGPA}
              onChange={(e) => setFormData({ ...formData, finalGPA: e.target.value })}
              className="w-full max-w-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm font-bold text-blue-800 font-mono"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700">لیست دروس و نمرات:</label>
            {formData.subjectGrades.map((sub, idx) => (
              <div key={idx} className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200">
                <input
                  type="text"
                  value={sub.subject}
                  onChange={(e) => {
                    const updated = [...formData.subjectGrades];
                    updated[idx].subject = e.target.value;
                    setFormData({ ...formData, subjectGrades: updated });
                  }}
                  className="flex-1 px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs"
                />
                <input
                  type="text"
                  value={sub.grade}
                  onChange={(e) => {
                    const updated = [...formData.subjectGrades];
                    updated[idx].grade = e.target.value;
                    setFormData({ ...formData, subjectGrades: updated });
                  }}
                  className="w-24 px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs font-bold font-mono text-center text-emerald-700"
                />
                <button
                  onClick={() => handleDeleteGrade(idx)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          {/* Add Subject */}
          <form onSubmit={handleAddGrade} className="flex items-center gap-2 pt-2">
            <input
              type="text"
              value={newSubject}
              onChange={(e) => setNewSubject(e.target.value)}
              placeholder="نام درس جدید"
              className="flex-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
            />
            <input
              type="text"
              value={newGrade}
              onChange={(e) => setNewGrade(e.target.value)}
              placeholder="نمره (مثال: ۲۰.۰۰)"
              className="w-32 px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-mono text-center"
            />
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg text-xs font-bold cursor-pointer"
            >
              افزودن درس
            </button>
          </form>
        </div>
      )}

      {/* TAB 8: RANKS */}
      {activeTab === 'ranks' && (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-4">
          <h2 className="text-base font-bold text-slate-800 mb-2 flex items-center gap-2">
            <Award className="w-5 h-5 text-blue-600" />
            <span>ویرایش رتبه، نمرات و وضعیت پذیرش کنکور</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">رتبه در سهمیه</label>
              <input
                type="text"
                value={formData.quotaRank}
                onChange={(e) => setFormData({ ...formData, quotaRank: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-emerald-700 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">رتبه کشوری</label>
              <input
                type="text"
                value={formData.nationalRank}
                onChange={(e) => setFormData({ ...formData, nationalRank: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-blue-700 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">نمره کل تراز کنکور</label>
              <input
                type="text"
                value={formData.totalScore}
                onChange={(e) => setFormData({ ...formData, totalScore: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">وضعیت مجاز انتخاب رشته</label>
              <input
                type="text"
                value={formData.qualificationStatus}
                onChange={(e) => setFormData({ ...formData, qualificationStatus: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">وضعیت دانشگاه فرهنگیان</label>
              <input
                type="text"
                value={formData.farhangianStatus}
                onChange={(e) => setFormData({ ...formData, farhangianStatus: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
