import React, { useState, useEffect } from 'react';
import { 
  User, 
  ArrowLeft, 
  RotateCw, 
  Calculator, 
  AlertCircle, 
  ShieldCheck,
  CreditCard,
  Eye,
  EyeOff
} from 'lucide-react';
import { normalizeDigits, toPersianDigits } from '../utils/persianUtils';
import { RecoveryModal } from './RecoveryModal';
import { SiteConfig } from '../types/admin';

interface LoginFormProps {
  config: SiteConfig;
  onSuccessLogin: (username: string, nationalId: string) => void;
  onAdminTrigger?: () => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ 
  config,
  onSuccessLogin,
  onAdminTrigger
}) => {
  const [username, setUsername] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [captchaInput, setCaptchaInput] = useState('');
  
  // Security Masking States (Hidden by default for privacy)
  const [showUsername, setShowUsername] = useState(false);
  const [showNationalId, setShowNationalId] = useState(false);
  
  // Math Captcha state
  const [num1, setNum1] = useState(14);
  const [num2, setNum2] = useState(7);
  
  // UI states
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRecoveryOpen, setIsRecoveryOpen] = useState(false);
  const [shake, setShake] = useState(false);

  // Generate new math captcha
  const generateCaptcha = () => {
    const n1 = Math.floor(Math.random() * 15) + 3;
    const n2 = Math.floor(Math.random() * 9) + 2;
    setNum1(n1);
    setNum2(n2);
    setCaptchaInput('');
  };

  useEffect(() => {
    generateCaptcha();
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Normalize inputs
    const normalizedUsername = username.trim();
    const normalizedId = normalizeDigits(nationalId).trim();
    const normalizedCaptcha = normalizeDigits(captchaInput).trim();

    // Validate empty
    if (!normalizedUsername) {
      triggerError('لطفاً نام کاربری را وارد کنید.');
      return;
    }

    if (!normalizedId) {
      triggerError('لطفاً کد ملی را وارد کنید.');
      return;
    }

    if (!normalizedCaptcha) {
      triggerError('لطفاً حاصل جمع کد امنیتی را وارد کنید.');
      return;
    }

    // Validate Captcha
    const expectedSum = num1 + num2;
    if (parseInt(normalizedCaptcha, 10) !== expectedSum) {
      triggerError('کد امنیتی (حاصل جمع) اشتباه است. لطفاً مجدداً تلاش کنید.');
      generateCaptcha();
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      // Check against dynamically configured allowed users
      const match = config.allowedUsers.find(
        (u) => u.username.trim() === normalizedUsername && 
               normalizeDigits(u.nationalId).trim() === normalizedId &&
               u.status === 'active'
      );

      if (match) {
        setIsLoading(false);
        onSuccessLogin(match.username, match.nationalId);
      } else {
        setIsLoading(false);
        triggerError('نام کاربری یا کد ملی وارد شده نادرست است.');
        generateCaptcha();
      }
    }, 450);
  };

  const triggerError = (msg: string) => {
    setErrorMsg(msg);
    setShake(true);
    setTimeout(() => setShake(false), 500);
  };

  return (
    <div className="w-full flex flex-col items-center justify-center p-4" dir="rtl">
      {/* Professional Polish Main Card */}
      <div 
        id="login-card"
        className={`w-full max-w-[420px] bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden transition-all duration-300 ${
          shake ? 'animate-bounce' : ''
        }`}
      >
        {/* Professional Blue Header */}
        <div className="bg-blue-700 p-6 text-center relative">
          <div className="w-12 h-12 rounded-full bg-blue-600/60 border border-blue-400/30 flex items-center justify-center mx-auto mb-3 text-white shadow-xs">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h1 id="form-title" className="text-white text-2xl font-bold mb-1 tracking-tight">
            ورود به سامانه جامع
          </h1>
          <p className="text-blue-100 text-sm font-normal">
            لطفاً اطلاعات کاربری خود را جهت ورود وارد نمایید
          </p>
        </div>

        {/* Card Body */}
        <div className="p-7 sm:p-8">
          {/* Error Message */}
          {errorMsg && (
            <div 
              id="error-alert"
              className="mb-5 p-3.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs sm:text-sm font-medium flex items-start gap-2.5 animate-in fade-in slide-in-from-top-2 duration-200"
            >
              <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 shrink-0 text-rose-600 mt-0.5" />
              <div className="leading-relaxed">{errorMsg}</div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-5" noValidate>
            {/* Input 1: Username (Masked by default) */}
            <div id="username-group">
              <div className="flex items-center justify-between mb-2">
                <label className="block text-slate-700 text-sm font-semibold text-right">
                  نام کاربری (محرمانه)
                </label>
                <span className="text-[11px] text-slate-400">مخفی در هنگام تایپ</span>
              </div>
              <div className="relative flex items-center">
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                  <User className="h-5 w-5" />
                </div>
                <input
                  id="username-input"
                  type={showUsername ? 'text' : 'password'}
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="نام کاربری را وارد کنید"
                  className="block w-full pr-11 pl-11 py-3 border border-slate-300 rounded-lg bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200 text-sm tracking-normal text-right"
                  autoComplete="off"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowUsername(!showUsername)}
                  className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                  title={showUsername ? 'مخفی‌سازی نام کاربری' : 'نمایش نام کاربری'}
                >
                  {showUsername ? (
                    <EyeOff className="h-4.5 w-4.5" />
                  ) : (
                    <Eye className="h-4.5 w-4.5" />
                  )}
                </button>
              </div>
            </div>

            {/* Input 2: National ID (Masked by default) */}
            <div id="national-id-group">
              <div className="flex items-center justify-between mb-2">
                <label className="block text-slate-700 text-sm font-semibold text-right">
                  کد ملی (محرمانه)
                </label>
                <span className="text-[11px] text-slate-400">مخفی در هنگام تایپ</span>
              </div>
              <div className="relative flex items-center">
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                  <CreditCard className="h-5 w-5" />
                </div>
                <input
                  id="national-id-input"
                  type={showNationalId ? 'text' : 'password'}
                  value={nationalId}
                  onChange={(e) => setNationalId(e.target.value)}
                  placeholder="کد ملی ۱۰ رقمی"
                  maxLength={10}
                  className="block w-full pr-11 pl-11 py-3 border border-slate-300 rounded-lg bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200 text-sm font-mono tracking-widest text-right"
                  autoComplete="off"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowNationalId(!showNationalId)}
                  className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                  title={showNationalId ? 'مخفی‌سازی کد ملی' : 'نمایش کد ملی'}
                >
                  {showNationalId ? (
                    <EyeOff className="h-4.5 w-4.5" />
                  ) : (
                    <Eye className="h-4.5 w-4.5" />
                  )}
                </button>
              </div>
            </div>

            {/* Input 3: Math Captcha */}
            <div id="captcha-group" className="bg-slate-50 p-4 rounded-lg border border-slate-200">
              <div className="flex items-center justify-between mb-3">
                <span className="text-slate-600 text-sm font-medium flex items-center gap-1.5">
                  <Calculator className="w-4 h-4 text-slate-400" />
                  کد امنیتی (جمع اعداد):
                </span>
                <div className="flex items-center gap-2">
                  <div className="bg-blue-100 text-blue-800 px-3.5 py-1.5 rounded-lg font-bold text-base tracking-wider border border-blue-200 flex items-center gap-1 select-none">
                    <span>{toPersianDigits(num1)} + {toPersianDigits(num2)} = ؟</span>
                  </div>
                  <button
                    type="button"
                    onClick={generateCaptcha}
                    className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-slate-200/80 rounded-lg transition-colors cursor-pointer"
                    title="تغییر کد امنیتی"
                  >
                    <RotateCw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <input
                id="captcha-input"
                type="text"
                value={captchaInput}
                onChange={(e) => setCaptchaInput(e.target.value)}
                placeholder="حاصل جمع را وارد کنید"
                className="block w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-center text-base font-semibold bg-white text-slate-800"
                autoComplete="off"
                required
              />
            </div>

            {/* Login Button */}
            <button
              id="submit-login-button"
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold py-3 px-4 rounded-lg shadow-md transition duration-200 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>در حال اعتبارسنجی...</span>
                </div>
              ) : (
                <>
                  <span>ورود به سامانه</span>
                  <ArrowLeft className="w-5 h-5" />
                </>
              )}
            </button>
          </form>

          {/* Recovery Link */}
          <div className="text-center mt-5">
            <button
              id="recovery-link"
              type="button"
              onClick={() => setIsRecoveryOpen(true)}
              className="text-sm font-semibold text-slate-600 hover:text-blue-600 transition-colors cursor-pointer"
            >
              فراموشی رمز یا نام کاربری؟
            </button>
          </div>
        </div>

        {/* Card Footer */}
        <div className="bg-slate-50 p-4 text-center border-t border-slate-100">
          <p className="text-slate-500 text-xs">
            کلیه حقوق مادی و معنوی این سامانه متعلق به سازمان مرکزی می‌باشد
          </p>
        </div>
      </div>

      {/* Bottom Security Status */}
      <div className="mt-6 text-slate-400 text-xs flex items-center justify-center gap-6">
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
          <span>{config.securityNotice || 'اتصال امن و رمزنگاری شده'}</span>
        </div>
        <div className="select-none">
          نسخه {config.version || '۴.۲.۰'}
        </div>
      </div>

      {/* Recovery Modal */}
      <RecoveryModal
        isOpen={isRecoveryOpen}
        onClose={() => setIsRecoveryOpen(false)}
      />
    </div>
  );
};
