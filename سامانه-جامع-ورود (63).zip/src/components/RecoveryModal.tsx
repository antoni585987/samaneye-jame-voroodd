import React, { useState } from 'react';
import { X, KeyRound, CheckCircle2, AlertCircle, ShieldAlert } from 'lucide-react';
import { normalizeDigits } from '../utils/persianUtils';

interface RecoveryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RecoveryModal: React.FC<RecoveryModalProps> = ({ isOpen, onClose }) => {
  const [nationalId, setNationalId] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  if (!isOpen) return null;

  const handleRecover = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanId = normalizeDigits(nationalId).trim();
    if (cleanId === '2960931394') {
      setStatus('success');
      setMessage('پیامک حاوی لینک بازیابی و احراز هویت به شماره همراه ثبت‌شده برای این کد ملی ارسال شد.');
    } else {
      setStatus('error');
      setMessage('کد ملی وارد شده در سامانه معتبر نمی‌باشد.');
    }
  };

  const handleReset = () => {
    setStatus('idle');
    setNationalId('');
    setPhoneNumber('');
    setMessage('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl border border-slate-200 relative"
        dir="rtl"
      >
        {/* Blue Header */}
        <div className="bg-blue-700 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">بازیابی اطلاعات کاربری</h3>
              <p className="text-xs text-blue-100 mt-0.5">درخواست ارسال کد بازیابی</p>
            </div>
          </div>

          <button
            onClick={handleReset}
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            title="بستن"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {status === 'success' ? (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 text-emerald-800 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-sm">درخواست ثبت شد</div>
                  <div className="text-xs leading-relaxed mt-1 text-slate-700">{message}</div>
                </div>
              </div>

              <button
                type="button"
                onClick={handleReset}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold text-sm transition duration-200 cursor-pointer"
              >
                بازگشت به صفحه ورود
              </button>
            </div>
          ) : (
            <form onSubmit={handleRecover} className="space-y-4">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 text-xs flex items-start gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>جهت حفظ امنیت حساب، اطلاعات هویتی شما پس از تایید به شماره ثبت‌شده ارسال خواهد شد.</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">کد ملی</label>
                <input
                  type="text"
                  value={nationalId}
                  onChange={(e) => setNationalId(e.target.value)}
                  placeholder="کد ملی ۱۰ رقمی"
                  maxLength={10}
                  dir="ltr"
                  className="w-full text-center px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200"
                  required
                />
              </div>

              {status === 'error' && (
                <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{message}</span>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white py-2.5 rounded-lg font-bold text-sm transition duration-200 shadow-sm cursor-pointer"
                >
                  ارسال لینک بازیابی
                </button>
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-medium transition duration-200 cursor-pointer"
                >
                  انصراف
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 text-center">
          <p className="text-slate-400 text-xs">احراز هویت دومرحله‌ای سامانه امن</p>
        </div>
      </div>
    </div>
  );
};
