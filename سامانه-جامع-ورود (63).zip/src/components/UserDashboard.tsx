import React, { useState } from 'react';
import { 
  UserCheck, 
  LogOut, 
  ShieldCheck, 
  Calendar, 
  Clock, 
  FileText, 
  CheckCircle, 
  Bell, 
  Lock, 
  Fingerprint,
  ChevronLeft,
  AlertTriangle,
  Info,
  Megaphone,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { toPersianDigits } from '../utils/persianUtils';
import { SiteConfig, Announcement } from '../types/admin';

interface UserDashboardProps {
  config: SiteConfig;
  username: string;
  nationalId: string;
  onLogout: () => void;
  onOpenElectronicDossier: () => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  config,
  username,
  nationalId,
  onLogout,
  onOpenElectronicDossier,
}) => {
  const loginTime = new Intl.DateTimeFormat('fa-IR', {
    dateStyle: 'full',
    timeStyle: 'medium',
  }).format(new Date());

  const activeAnnouncements = (config.announcements || []).filter((a) => a.isActive);
  const [expandedAnnId, setExpandedAnnId] = useState<string | null>(
    activeAnnouncements.length > 0 ? activeAnnouncements[0].id : null
  );

  const toggleExpand = (id: string) => {
    setExpandedAnnId((prev) => (prev === id ? null : id));
  };

  const getPriorityBadge = (priority: Announcement['priority']) => {
    switch (priority) {
      case 'urgent':
        return (
          <span className="inline-flex items-center gap-1 bg-rose-100 text-rose-800 text-[11px] font-bold px-2 py-0.5 rounded-full border border-rose-200">
            <AlertTriangle className="w-3 h-3" />
            فوری و مهم
          </span>
        );
      case 'important':
        return (
          <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-900 text-[11px] font-bold px-2 py-0.5 rounded-full border border-amber-200">
            <Bell className="w-3 h-3" />
            اطلاعیه مهم
          </span>
        );
      case 'info':
      default:
        return (
          <span className="inline-flex items-center gap-1 bg-blue-100 text-blue-900 text-[11px] font-bold px-2 py-0.5 rounded-full border border-blue-200">
            <Info className="w-3 h-3" />
            اطلاع‌رسانی عمومی
          </span>
        );
    }
  };

  const getCardStyle = (priority: Announcement['priority']) => {
    switch (priority) {
      case 'urgent':
        return 'border-rose-200 bg-rose-50/40 hover:bg-rose-50/70';
      case 'important':
        return 'border-amber-200 bg-amber-50/30 hover:bg-amber-50/60';
      case 'info':
      default:
        return 'border-blue-100 bg-blue-50/30 hover:bg-blue-50/60';
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4" dir="rtl">
      {/* Top Banner Card */}
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 mb-6 overflow-hidden">
        {/* Blue Header Accent */}
        <div className="bg-[#1e469a] p-6 sm:p-7 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white shrink-0 shadow-inner">
              <UserCheck className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-black text-white">{username}</h1>
                <span className="inline-flex items-center gap-1 bg-emerald-500/20 text-emerald-100 border border-emerald-400/30 text-xs px-2.5 py-0.5 rounded-full font-medium">
                  <CheckCircle className="w-3.5 h-3.5" />
                  احراز هویت شده
                </span>
              </div>
              <p className="text-sm text-blue-100 mt-1 flex items-center gap-2">
                <span>کد ملی:</span>
                <span className="font-mono font-bold tracking-wider text-white">
                  {toPersianDigits(nationalId)}
                </span>
              </p>
            </div>
          </div>

          <button
            onClick={onLogout}
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white border border-white/20 px-4 py-2 rounded-xl font-medium text-sm transition duration-200 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>خروج از حساب</span>
          </button>
        </div>

        {/* Status bar */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
            <span>نشست کاربری امن و فعال است</span>
          </div>
          <div className="font-mono text-[11px] text-slate-400">شناسه اتصال: TLS-256</div>
        </div>
      </div>

      {/* SECTION: اطلاعیه‌ها و پیام‌های مهم (Announcements) */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 sm:p-6 mb-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-800">اطلاعیه‌ها و پیام‌های مهم</h2>
              <p className="text-xs text-slate-400">آخرین بخش‌نامه‌ها و اعلانات مربوط به داوطلب</p>
            </div>
          </div>
          <span className="bg-slate-100 text-slate-700 text-xs font-bold px-2.5 py-1 rounded-lg">
            {toPersianDigits(activeAnnouncements.length)} اطلاعیه فعال
          </span>
        </div>

        {activeAnnouncements.length === 0 ? (
          <div className="p-6 text-center text-slate-400 text-sm bg-slate-50 rounded-xl border border-dashed border-slate-200">
            در حال حاضر اطلاعیه جدیدی برای نمایش وجود ندارد.
          </div>
        ) : (
          <div className="space-y-3">
            {activeAnnouncements.map((ann) => {
              const isExpanded = expandedAnnId === ann.id;
              return (
                <div
                  key={ann.id}
                  className={`border rounded-xl transition-all overflow-hidden ${getCardStyle(ann.priority)}`}
                >
                  <div
                    onClick={() => toggleExpand(ann.id)}
                    className="p-3.5 sm:p-4 flex items-center justify-between gap-3 cursor-pointer select-none"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 flex-1">
                      <div className="flex items-center gap-2">
                        {getPriorityBadge(ann.priority)}
                        <span className="font-bold text-slate-800 text-sm sm:text-base">
                          {ann.title}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono sm:mr-auto">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        {ann.date}
                      </span>
                    </div>

                    <div className="text-slate-400 hover:text-slate-700 p-1">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="px-4 pb-4 pt-1 text-xs sm:text-sm text-slate-700 leading-relaxed border-t border-slate-200/50">
                      <p className="whitespace-pre-line bg-white/70 p-3 rounded-lg border border-slate-200/40">
                        {ann.content}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Grid of details & services */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Fast Actions & Open Dossier Button */}
        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-200 flex flex-col justify-between order-first md:order-last md:col-span-1">
          <div>
            <div className="flex items-center gap-2.5 text-slate-800 font-bold text-base mb-4">
              <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-700 border border-blue-100">
                <Bell className="w-4 h-4" />
              </div>
              <span>خدمات پرونده الکترونیک</span>
            </div>
            <div className="space-y-3">
              {/* Primary Action Button: مشاهده پرونده الکترونیک */}
              <button
                id="open-electronic-dossier-button"
                type="button"
                onClick={onOpenElectronicDossier}
                className="w-full p-4 bg-[#1e469a] hover:bg-[#183980] active:bg-[#142e66] text-white transition duration-200 rounded-xl flex items-center justify-between cursor-pointer group text-right shadow-md shadow-blue-900/20"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-white/15 text-white flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-sm font-bold block">مشاهده پرونده الکترونیک</span>
                    <span className="text-[11px] text-blue-200">سراسری و دانشجو-معلم</span>
                  </div>
                </div>
                <ChevronLeft className="w-5 h-5 text-white group-hover:-translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-center text-slate-500 font-medium">
            خوش آمدید، {username}
          </div>
        </div>

        {/* Security & Access Info */}
        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-200 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5 text-slate-800 font-bold text-base mb-4">
              <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-700 border border-blue-100">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <span>امنیت نشست کاربری</span>
            </div>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500">وضعیت دسترسی:</span>
                <span className="font-bold text-emerald-600">مجاز و تایید شده</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500">نوع احراز هویت:</span>
                <span className="font-medium text-slate-700">کد ملی دو مرحله‌ای</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-500">حفاظت ضد ربات:</span>
                <span className="font-medium text-slate-700">کپچای ریاضی فعال</span>
              </div>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2 text-xs text-slate-400">
            <Lock className="w-3.5 h-3.5" />
            <span>نشست شما رمزنگاری شده است</span>
          </div>
        </div>

        {/* Time and Session Logs */}
        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-200 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5 text-slate-800 font-bold text-base mb-4">
              <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-700 border border-blue-100">
                <Clock className="w-4 h-4" />
              </div>
              <span>اطلاعات ورود به سامانه</span>
            </div>
            <div className="space-y-3 text-sm">
              <div className="py-2 border-b border-slate-100">
                <span className="text-slate-500 block text-xs mb-1">زمان ورود:</span>
                <span className="font-medium text-slate-800 text-xs">{loginTime}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500">پروتکل امنیتی:</span>
                <span className="font-mono text-xs font-semibold text-slate-700">TLS 1.3 / SHA-256</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-500">سطح دسترسی:</span>
                <span className="text-slate-700 text-xs font-semibold">کاربر رسمی سامانه</span>
              </div>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2 text-xs text-slate-400">
            <Fingerprint className="w-3.5 h-3.5" />
            <span>شناسه کاربر ثبت شد</span>
          </div>
        </div>
      </div>

      {/* Bottom Footer Info */}
      <div className="mt-8 text-center text-slate-400 text-xs flex items-center justify-center gap-6">
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
          <span>{config.securityNotice || 'اتصال امن و رمزنگاری شده برقرار است'}</span>
        </div>
        <div>نسخه {config.version || '۴.۲.۰'}</div>
      </div>
    </div>
  );
};
