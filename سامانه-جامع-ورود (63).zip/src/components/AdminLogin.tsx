import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  User, 
  KeyRound, 
  RotateCw, 
  Calculator, 
  AlertCircle, 
  ArrowLeft,
  Eye,
  EyeOff,
  Sliders
} from 'lucide-react';
import { normalizeDigits, toPersianDigits } from '../utils/persianUtils';

interface AdminLoginProps {
  onSuccess: () => void;
  onExitToSite: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onSuccess, onExitToSite }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [captchaInput, setCaptchaInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showUsername, setShowUsername] = useState(false);

  // Math Captcha state
  const [num1, setNum1] = useState(12);
  const [num2, setNum2] = useState(8);

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const generateCaptcha = () => {
    const n1 = Math.floor(Math.random() * 18) + 4;
    const n2 = Math.floor(Math.random() * 12) + 3;
    setNum1(n1);
    setNum2(n2);
    setCaptchaInput('');
  };

  useEffect(() => {
    generateCaptcha();
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const normUser = username.trim();
    const normPass = password.trim();
    const normCaptcha = normalizeDigits(captchaInput).trim();

    if (!normUser || !normPass) {
      setErrorMsg('لطفاً نام کاربری و رمز عبور مدیریت را وارد کنید.');
      return;
    }

    if (!normCaptcha) {
      setErrorMsg('لطفاً حاصل جمع کد امنیتی را وارد کنید.');
      return;
    }

    if (parseInt(normCaptcha, 10) !== num1 + num2) {
      setErrorMsg('کد امنیتی اشتباه است. لطفاً مجدداً تلاش کنید.');
      generateCaptcha();
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      if (normUser === 'dodozoo' && normPass === 'dodozoo') {
        setIsLoading(false);
        onSuccess();
      } else {
        setIsLoading(false);
        setErrorMsg('نام کاربری یا کلمه عبور پنل مدیریت نادرست است.');
        generateCaptcha();
      }
    }, 400);
  };

  return (
    <div className="w-full flex flex-col items-center justify-center p-4 max-w-[420px] mx-auto" dir="rtl">
      {/* Admin Card */}
      <div className="w-full bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-slate-900 p-6 text-center text-white relative">
          <div className="w-13 h-13 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto mb-3 text-amber-400 shadow-md">
            <Sliders className="w-7 h-7" />
          </div>
          <div className="inline-block bg-amber-400/10 text-amber-300 border border-amber-400/20 text-[11px] font-bold px-2.5 py-0.5 rounded-full mb-1.5 font-mono">
            koonik.ir/dodozoo
          </div>
          <h1 className="text-white text-xl font-bold tracking-tight">
            پنل مدیریت و کنترل جامع سامانه
          </h1>
          <p className="text-slate-400 text-xs mt-1">
            ورود به بخش ویرایش و کنترل نقطه به نقطه سایت
          </p>
        </div>

        {/* Form Body */}
        <div className="p-7">
          {errorMsg && (
            <div className="mb-5 p-3.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs font-medium flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4.5" noValidate>
            {/* Username */}
            <div>
              <label className="block text-slate-700 text-xs font-bold mb-1.5">
                نام کاربری مدیریت
              </label>
              <div className="relative flex items-center">
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                  <User className="h-4.5 w-4.5" />
                </div>
                <input
                  type={showUsername ? 'text' : 'password'}
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="نام کاربری مدیریت"
                  className="w-full pr-10 pl-10 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-slate-800 transition"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowUsername(!showUsername)}
                  className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {showUsername ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-slate-700 text-xs font-bold">
                  رمز عبور مدیریت
                </label>
                <span className="text-[10px] text-slate-400">ورود نقطه‌ای (محرمانه)</span>
              </div>
              <div className="relative flex items-center">
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
                  <KeyRound className="h-4.5 w-4.5" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="رمز عبور مدیریت"
                  className="w-full pr-10 pl-10 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-slate-800 transition tracking-widest"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
                  title={showPassword ? 'مخفی‌سازی رمز' : 'نمایش رمز'}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Math Captcha */}
            <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200">
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-slate-600 text-xs font-medium flex items-center gap-1.5">
                  <Calculator className="w-3.5 h-3.5 text-slate-400" />
                  کد ضد ربات:
                </span>
                <div className="flex items-center gap-2">
                  <div className="bg-slate-200 text-slate-800 px-3 py-1 rounded-md font-bold text-sm select-none">
                    {toPersianDigits(num1)} + {toPersianDigits(num2)} = ؟
                  </div>
                  <button
                    type="button"
                    onClick={generateCaptcha}
                    className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <input
                type="text"
                value={captchaInput}
                onChange={(e) => setCaptchaInput(e.target.value)}
                placeholder="حاصل جمع اعداد"
                className="w-full py-2 px-3 border border-slate-300 rounded-lg text-center text-sm font-semibold bg-white"
                required
              />
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 px-4 rounded-lg shadow-md transition duration-200 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>در حال بررسی اعتبار...</span>
                </div>
              ) : (
                <>
                  <span>ورود به پنل مدیریت</span>
                  <ArrowLeft className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-5 text-center">
            <button
              onClick={onExitToSite}
              className="text-xs text-slate-500 hover:text-blue-600 font-semibold cursor-pointer"
            >
              ← بازگشت به سامانه اصلی
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 text-center text-[11px] text-slate-400">
          سامانه امن دسترسی ریشه | IP مجاز
        </div>
      </div>
    </div>
  );
};
