import React, { useState, useRef } from 'react';
import { 
  Menu, 
  LogOut, 
  Globe, 
  UserPlus, 
  ArrowLeft, 
  X, 
  CheckCircle2, 
  FileText, 
  Calendar, 
  MapPin, 
  Clock, 
  Printer, 
  Award,
  BookOpen,
  GraduationCap,
  ShieldCheck,
  User,
  School,
  TrendingUp,
  AlertCircle,
  Upload,
  Download,
  Image as ImageIcon,
  Plus,
  Trash2
} from 'lucide-react';
import { toPersianDigits } from '../utils/persianUtils';
import { SiteConfig, DossierCard, ExamVenue } from '../types/admin';

interface ElectronicDossierPageProps {
  config: SiteConfig;
  username: string;
  nationalId: string;
  onBackToDashboard: () => void;
  onLogout: () => void;
  onOpenAdmin?: () => void;
  onUpdateConfig?: (newConfig: SiteConfig) => void;
}

type ModalType = 'none' | 'registration' | 'card' | 'change_venue' | 'report_card' | 'rank_results' | string;

export const ElectronicDossierPage: React.FC<ElectronicDossierPageProps> = ({
  config,
  username,
  nationalId,
  onBackToDashboard,
  onLogout,
  onOpenAdmin,
  onUpdateConfig,
}) => {
  const [activeModal, setActiveModal] = useState<ModalType>('none');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // Venue State
  const [selectedVenue, setSelectedVenue] = useState(
    config.venues && config.venues.length > 0 ? config.venues[0].name : 'تهران - منطقه ۵ (دانشکده مهندسی)'
  );
  const [venueSaved, setVenueSaved] = useState(false);
  const [showAddVenueInline, setShowAddVenueInline] = useState(false);
  const [newCityName, setNewCityName] = useState('');
  const [newVenueName, setNewVenueName] = useState('');

  // Exam Card Upload State
  const [cardImage, setCardImage] = useState<string | null>(config.examCardImage || null);
  const [candidatePhoto, setCandidatePhoto] = useState<string | null>(config.candidatePhoto || null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadSuccessMsg, setUploadSuccessMsg] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (file: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setCardImage(dataUrl);
      if (onUpdateConfig) {
        onUpdateConfig({
          ...config,
          examCardImage: dataUrl,
        });
      }
      setUploadSuccessMsg('تصویر کارت با موفقیت بارگذاری شد!');
      setTimeout(() => setUploadSuccessMsg(null), 3000);
    };
    reader.readAsDataURL(file);
  };

  const handlePhotoUpload = (file: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setCandidatePhoto(dataUrl);
      if (onUpdateConfig) {
        onUpdateConfig({
          ...config,
          candidatePhoto: dataUrl,
        });
      }
      setUploadSuccessMsg('عکس پرسنلی داوطلب با موفقیت ثبت شد!');
      setTimeout(() => setUploadSuccessMsg(null), 3000);
    };
    reader.readAsDataURL(file);
  };

  const handleDownloadCard = () => {
    if (cardImage) {
      // Direct file download of uploaded image
      const link = document.createElement('a');
      link.href = cardImage;
      link.download = `kart_vorood_azmoon_${nationalId}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else {
      // Print/Save as PDF standard trigger
      window.print();
    }
  };

  const handleAddNewVenue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVenueName.trim()) return;
    const newVenue: ExamVenue = {
      id: 'v-' + Date.now(),
      city: newCityName.trim() || 'حوزه جدید',
      name: `${newCityName.trim() ? newCityName.trim() + ' - ' : ''}${newVenueName.trim()}`,
      code: 'V-' + Math.floor(100 + Math.random() * 900),
    };
    const updatedVenues = [...(config.venues || []), newVenue];
    if (onUpdateConfig) {
      onUpdateConfig({
        ...config,
        venues: updatedVenues,
      });
    }
    setSelectedVenue(newVenue.name);
    setNewCityName('');
    setNewVenueName('');
    setShowAddVenueInline(false);
  };

  const getCardIcon = (iconType: DossierCard['iconType']) => {
    switch (iconType) {
      case 'user-plus':
        return <UserPlus className="w-6 h-6 stroke-[2.2]" />;
      case 'id-card':
        return (
          <svg 
            className="w-6 h-6 stroke-[2.2]" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2.2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <rect width="20" height="15" x="2" y="4.5" rx="3" />
            <line x1="2" x2="22" y1="9.5" y2="9.5" />
          </svg>
        );
      case 'file-text':
        return <FileText className="w-6 h-6 stroke-[2.2]" />;
      case 'award':
        return <Award className="w-6 h-6 stroke-[2.2]" />;
      case 'map-pin':
        return <MapPin className="w-6 h-6 stroke-[2.2]" />;
      case 'school':
        return <School className="w-6 h-6 stroke-[2.2]" />;
      default:
        return <FileText className="w-6 h-6 stroke-[2.2]" />;
    }
  };

  const handleCardClick = (card: DossierCard) => {
    if (card.id === 'card-1') setActiveModal('registration');
    else if (card.id === 'card-2') setActiveModal('card');
    else if (card.id === 'card-3') setActiveModal('change_venue');
    else if (card.id === 'card-4') setActiveModal('report_card');
    else if (card.id === 'card-5') setActiveModal('rank_results');
    else setActiveModal(card.id);
  };

  const activeCards = config.cards.filter((c) => c.isActive);

  return (
    <div className="w-full max-w-[480px] mx-auto bg-white min-h-screen rounded-3xl shadow-2xl border border-slate-100/90 overflow-hidden flex flex-col justify-between relative my-2" dir="rtl">
      {/* Top Navigation Bar */}
      <div>
        <div className="px-5 py-4 flex items-center justify-between border-b border-slate-100 bg-white sticky top-0 z-20 shadow-2xs">
          {/* Top Left: Exit / Return Button with Red Border */}
          <button
            onClick={onBackToDashboard}
            className="flex items-center gap-2 border border-rose-300 hover:border-rose-400 bg-white hover:bg-rose-50 text-[#e11d48] px-3.5 py-1.5 rounded-xl font-bold text-sm transition-all duration-150 cursor-pointer"
            title="بازگشت به داشبورد"
          >
            <span>خروج</span>
            <LogOut className="w-4 h-4 text-[#e11d48] rotate-180" />
          </button>

          {/* Top Right: Hamburger Menu Icon */}
          <button
            onClick={() => setIsMenuOpen(true)}
            className="p-2 text-slate-700 hover:text-blue-700 hover:bg-slate-50 rounded-xl transition-colors cursor-pointer"
            title="منوی امکانات"
          >
            <Menu className="w-6 h-6 stroke-[2.2]" />
          </button>
        </div>

        {/* Hero Title Section */}
        <div className="px-6 pt-6 pb-2 text-center flex flex-col items-center">
          {/* Big Cyan Title */}
          <h1 className="text-[26px] sm:text-[28px] font-black text-[#0284c7] tracking-tight">
            {config.siteTitle || 'سراسری و دانشجو-معلم'}
          </h1>

          {/* Subtitle description */}
          <p className="text-slate-500 text-sm font-normal mt-2 leading-relaxed max-w-[340px]">
            {config.siteSubtitle || 'مدیریت آزمون سراسری و دانشجو-معلم و فرایندهای مرتبط'}
          </p>

          {/* Pill Badge */}
          <div className="mt-4">
            <div className="inline-flex items-center gap-2 bg-[#dce7fc] text-[#1e469a] px-5 py-2 rounded-full font-bold text-sm border border-blue-200/70 shadow-xs select-none">
              <span>{config.badgeText || 'سراسری و دانشجو معلم'}</span>
              <Globe className="w-4 h-4 text-[#1e469a]" />
            </div>
          </div>
        </div>

        {/* Scrollable Content Section: Dynamic Cards from Admin Config */}
        <div className="p-6 space-y-6">
          {activeCards.map((card) => (
            <div 
              key={card.id}
              className="bg-white rounded-2xl shadow-[0_4px_24px_-4px_rgba(0,0,0,0.07)] border border-slate-200/90 overflow-hidden relative pt-1.5 transition-transform hover:-translate-y-0.5 duration-200"
            >
              {/* Top Cyan Accent Line */}
              <div className="absolute top-0 right-0 left-0 h-1.5 bg-[#0284c7]"></div>

              <div className="p-6">
                {/* Header inside Card */}
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-black text-slate-800">
                    {card.title}
                  </h2>

                  {/* Icon Box */}
                  <div className="w-13 h-13 rounded-2xl bg-[#dce7fc] flex items-center justify-center text-[#1e469a] shrink-0 shadow-xs">
                    {getCardIcon(card.iconType)}
                  </div>
                </div>

                {/* Card Subtitle */}
                <p className="text-slate-500 text-[13.5px] font-normal mt-3 text-center sm:text-right">
                  {card.subtitle}
                </p>

                {/* Action Button */}
                <button
                  onClick={() => handleCardClick(card)}
                  className="w-full h-12 bg-[#1e469a] hover:bg-[#183980] active:bg-[#142e66] text-white font-bold text-[15px] rounded-xl flex items-center justify-center gap-2.5 mt-5 shadow-md shadow-blue-900/20 active:scale-[0.99] transition-all cursor-pointer"
                >
                  <span>{card.buttonText || 'ورود به بخش'}</span>
                  <ArrowLeft className="w-4.5 h-4.5 stroke-[2.5]" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer info bar */}
      <div className="p-4 bg-slate-50 border-t border-slate-100 text-center text-xs text-slate-400 flex items-center justify-between px-6">
        <span>سامانه جامع مدیریت پرونده الکترونیک</span>
        <span className="font-mono text-[11px] text-slate-400">نسخه {config.version || '۴.۲.۰'}</span>
      </div>

      {/* Modal 1: پرونده ثبت نام در آزمون */}
      {activeModal === 'registration' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl border border-slate-200 relative overflow-hidden" dir="rtl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800">پرونده ثبت‌نام آزمون</h3>
                  <p className="text-xs text-slate-400">{config.studyGroup}</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal('none')}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="my-5 space-y-3 text-sm">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center justify-between text-emerald-800">
                <span className="font-semibold text-xs">وضعیت ثبت‌نام:</span>
                <span className="font-bold text-xs flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  {config.registrationStatus}
                </span>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl space-y-2.5 text-xs text-slate-600">
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span>نام و نام خانوادگی:</span>
                  <span className="font-bold text-slate-800">{username}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span>کد ملی داوطلب:</span>
                  <span className="font-mono font-bold text-slate-800">{toPersianDigits(nationalId)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span>گروه آزمایشی:</span>
                  <span className="font-bold text-slate-800">{config.studyGroup}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span>شماره پرونده:</span>
                  <span className="font-mono font-bold text-blue-700">{config.fileNumber}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setActiveModal('none')}
              className="w-full bg-[#1e469a] hover:bg-[#183980] text-white py-2.5 rounded-xl font-bold text-sm transition-colors cursor-pointer"
            >
              بستن
            </button>
          </div>
        </div>
      )}

      {/* Modal 2: کارت ورود به جلسه (With Upload & Download) */}
      {activeModal === 'card' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl border border-slate-200 relative overflow-hidden max-h-[92vh] overflow-y-auto" dir="rtl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
                  <School className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800">کارت شرکت در آزمون</h3>
                  <p className="text-xs text-slate-400">نوبت اول آزمون سراسری</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal('none')}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {uploadSuccessMsg && (
              <div className="my-3 p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{uploadSuccessMsg}</span>
              </div>
            )}

            {/* Exam Card Visual Body */}
            <div id="printable-exam-card" className="my-4 border-2 border-blue-100 rounded-2xl p-4 bg-gradient-to-b from-blue-50/40 via-white to-slate-50 relative overflow-hidden shadow-xs">
              {/* Candidate Info and Photo Header */}
              <div className="flex items-start justify-between gap-3 pb-3 border-b border-blue-100">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <User className="w-4 h-4 text-blue-700" />
                    <span className="font-black text-sm text-slate-800">{username}</span>
                  </div>
                  <div className="text-xs text-slate-500 flex items-center gap-1">
                    <span>کد ملی:</span>
                    <span className="bg-blue-100 text-blue-800 font-mono px-1.5 py-0.5 rounded text-[11px] font-bold">
                      {toPersianDigits(nationalId)}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500">
                    شماره داوطلبی: <strong className="font-mono text-slate-700">۴۲۹۰۱۸</strong>
                  </div>
                </div>

                {/* Candidate Photo (Custom uploaded or placeholder with upload trigger) */}
                <div className="relative group">
                  {candidatePhoto ? (
                    <div className="w-16 h-20 rounded-lg border-2 border-blue-200 overflow-hidden shadow-xs bg-slate-100">
                      <img 
                        src={candidatePhoto} 
                        alt={username} 
                        className="w-full h-full object-cover" 
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  ) : (
                    <div 
                      onClick={() => photoInputRef.current?.click()}
                      className="w-16 h-20 rounded-lg border-2 border-dashed border-blue-300 bg-blue-50/70 hover:bg-blue-100 flex flex-col items-center justify-center text-blue-600 cursor-pointer transition p-1 text-center"
                      title="آپلود عکس پرسنلی داوطلب"
                    >
                      <User className="w-6 h-6 text-blue-400" />
                      <span className="text-[9px] font-bold mt-1">عکس داوطلب</span>
                    </div>
                  )}
                  <input
                    ref={photoInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && handlePhotoUpload(e.target.files[0])}
                  />
                </div>
              </div>

              {/* Full Uploaded Exam Card View if available */}
              {cardImage && (
                <div className="mt-3 p-2 bg-white rounded-xl border border-slate-200">
                  <span className="text-[11px] font-bold text-slate-700 block mb-1.5 flex items-center gap-1">
                    <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                    تصویر پیوست کارت بارگذاری‌شده:
                  </span>
                  <div className="max-h-48 rounded-lg overflow-hidden border border-slate-100 flex items-center justify-center bg-slate-900/5">
                    <img 
                      src={cardImage} 
                      alt="Exam Card" 
                      className="max-h-44 w-auto object-contain rounded" 
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>
              )}

              {/* Details table */}
              <div className="space-y-2 mt-3 text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>تاریخ برگزاری: <strong>{config.examDate}</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>ساعت حضور در حوزه: <strong>{config.arrivalTime}</strong></span>
                </div>
                <div className="flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                  <span>آدرس حوزه: <strong>{config.examVenue} - {config.examHall}</strong></span>
                </div>
              </div>
            </div>

            {/* Custom Image / Document Upload Zone */}
            <div 
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={(e) => {
                e.preventDefault();
                setIsDragging(false);
                if (e.dataTransfer.files?.[0]) handleFileUpload(e.dataTransfer.files[0]);
              }}
              onClick={() => fileInputRef.current?.click()}
              className={`p-3.5 border-2 border-dashed rounded-xl text-center cursor-pointer transition ${
                isDragging 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-slate-300 hover:border-blue-400 bg-slate-50/70 hover:bg-blue-50/30'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,application/pdf"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
              />
              <Upload className="w-5 h-5 mx-auto text-blue-600 mb-1" />
              <div className="text-xs font-bold text-slate-700">
                {cardImage ? 'تغییر یا بارگذاری تصویر جدید کارت' : 'آپلود تصویر / فایل کارت ورود به جلسه'}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                کلیک کنید یا فایل را بکشید و رها کنید (PNG، JPG یا PDF)
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 mt-4">
              <button
                onClick={handleDownloadCard}
                className="flex-1 bg-[#1e469a] hover:bg-[#183980] text-white py-2.5 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 shadow-sm cursor-pointer"
              >
                {cardImage ? (
                  <>
                    <Download className="w-4 h-4" />
                    <span>دانلود و چاپ کارت</span>
                  </>
                ) : (
                  <>
                    <Printer className="w-4 h-4" />
                    <span>چاپ کارت آزمون</span>
                  </>
                )}
              </button>
              <button
                onClick={() => setActiveModal('none')}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-sm font-medium transition-colors cursor-pointer"
              >
                بستن
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 3: تغییر حوزه آزمون سراسری (With dynamic selectable venues & add venue) */}
      {activeModal === 'change_venue' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl border border-slate-200 relative overflow-hidden max-h-[92vh] overflow-y-auto" dir="rtl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800">تغییر حوزه امتحانی</h3>
                  <p className="text-xs text-slate-400">{config.studyGroup}</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal('none')}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="my-5 space-y-4 text-sm">
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-blue-800 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span>داوطلب گرامی، تغییر حوزه امتحانی تا ۴۸ ساعت قبل از برگزاری آزمون مجاز می‌باشد.</span>
              </div>

              {venueSaved ? (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                  <div>
                    <div className="font-bold text-sm">حوزه امتحانی با موفقیت تغییر یافت</div>
                    <div className="text-xs text-slate-700 mt-1 font-semibold">حوزه ثبت‌شده: {selectedVenue}</div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Select venue */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-xs font-bold text-slate-700">
                        انتخاب از بین حوزه‌های مجاز ({toPersianDigits(config.venues?.length || 0)} حوزه):
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowAddVenueInline(!showAddVenueInline)}
                        className="text-[11px] font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>{showAddVenueInline ? 'بستن فرم افزودن' : 'افزودن حوزه دلخواه'}</span>
                      </button>
                    </div>

                    <select
                      value={selectedVenue}
                      onChange={(e) => setSelectedVenue(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                    >
                      {config.venues && config.venues.map((v) => (
                        <option key={v.id} value={v.name}>
                          {v.name} {v.code ? `(${v.code})` : ''}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Inline Add New Venue Form */}
                  {showAddVenueInline && (
                    <form onSubmit={handleAddNewVenue} className="p-3 bg-blue-50/60 rounded-xl border border-blue-200 space-y-2.5 animate-in fade-in duration-150">
                      <div className="text-xs font-bold text-blue-950 flex items-center gap-1">
                        <Plus className="w-3.5 h-3.5 text-blue-600" />
                        <span>افزودن حوزه جدید برای انتخاب</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={newCityName}
                          onChange={(e) => setNewCityName(e.target.value)}
                          placeholder="نام شهر (مثال: کرج)"
                          className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                          required
                        />
                        <input
                          type="text"
                          value={newVenueName}
                          onChange={(e) => setNewVenueName(e.target.value)}
                          placeholder="نام دانشگاه / مدرسه"
                          className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                          required
                        />
                      </div>
                      <button
                        type="submit"
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white py-1.5 rounded-lg text-xs font-bold transition cursor-pointer"
                      >
                        ثبت و افزودن به لیست حوزه‌ها
                      </button>
                    </form>
                  )}

                  <button
                    onClick={() => {
                      setVenueSaved(true);
                      if (onUpdateConfig) {
                        onUpdateConfig({
                          ...config,
                          examVenue: selectedVenue,
                        });
                      }
                    }}
                    className="w-full bg-[#1e469a] hover:bg-[#183980] text-white py-2.5 rounded-xl font-bold text-sm transition-colors cursor-pointer shadow-sm"
                  >
                    ثبت تغییر حوزه آزمون
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={() => {
                setActiveModal('none');
                setVenueSaved(false);
              }}
              className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 rounded-xl font-bold text-sm transition-colors cursor-pointer"
            >
              بستن
            </button>
          </div>
        </div>
      )}

      {/* Modal 4: کارنامه آزمون نهایی */}
      {activeModal === 'report_card' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl border border-slate-200 relative overflow-hidden max-h-[90vh] overflow-y-auto" dir="rtl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800">کارنامه امتحانات نهایی</h3>
                  <p className="text-xs text-slate-400">سوابق تحصیلی معتبر دیپلم</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal('none')}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="my-4 space-y-3">
              <div className="bg-blue-50/70 p-3 rounded-xl flex items-center justify-between border border-blue-100 text-xs">
                <span className="text-slate-600">معدل کتبی نهایی:</span>
                <span className="text-base font-black text-blue-800 font-mono">{config.finalGPA}</span>
              </div>

              <div className="space-y-1.5 text-xs">
                {config.subjectGrades.map((sub, idx) => (
                  <div key={idx} className="flex justify-between p-2.5 bg-slate-50 rounded-lg">
                    <span className="font-semibold text-slate-700">{sub.subject}:</span>
                    <span className="font-bold text-emerald-700 font-mono">{sub.grade}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => window.print()}
                className="flex-1 bg-[#1e469a] hover:bg-[#183980] text-white py-2.5 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2"
              >
                <Printer className="w-4 h-4" />
                <span>دریافت نسخه PDF</span>
              </button>
              <button
                onClick={() => setActiveModal('none')}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-sm font-medium transition-colors"
              >
                بستن
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 5: رتبه و نتایج آزمون سراسری */}
      {activeModal === 'rank_results' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl border border-slate-200 relative overflow-hidden max-h-[90vh] overflow-y-auto" dir="rtl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800">کارنامه رتبه و نمرات</h3>
                  <p className="text-xs text-slate-400">آزمون سراسری سراسر کشور</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal('none')}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="my-4 space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl text-center">
                  <span className="text-[11px] text-emerald-800 block">{config.quotaTitle}:</span>
                  <span className="text-lg font-black text-emerald-700 font-mono">{config.quotaRank}</span>
                </div>
                <div className="bg-blue-50 border border-blue-200 p-3 rounded-xl text-center">
                  <span className="text-[11px] text-blue-800 block">رتبه کشوری (بدون سهمیه):</span>
                  <span className="text-lg font-black text-blue-800 font-mono">{config.nationalRank}</span>
                </div>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-xl space-y-2 text-xs text-slate-700">
                <div className="flex justify-between border-b border-slate-200/70 pb-1.5">
                  <span>وضعیت مجاز به انتخاب رشته:</span>
                  <span className="font-bold text-emerald-600">{config.qualificationStatus}</span>
                </div>
                <div className="flex justify-between border-b border-slate-200/70 pb-1.5">
                  <span>دانشگاه فرهنگیان:</span>
                  <span className="font-bold text-blue-700">{config.farhangianStatus}</span>
                </div>
                <div className="flex justify-between">
                  <span>نمره کل تراز (کنکور + سابقه):</span>
                  <span className="font-mono font-bold text-slate-900">{config.totalScore}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setActiveModal('none')}
              className="w-full bg-[#1e469a] hover:bg-[#183980] text-white py-2.5 rounded-xl font-bold text-sm transition-colors"
            >
              بازگشت
            </button>
          </div>
        </div>
      )}

      {/* Dynamic custom card modal if extra card clicked */}
      {typeof activeModal === 'string' && activeModal.startsWith('card-') && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl border border-slate-200 relative overflow-hidden" dir="rtl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-800">
                {config.cards.find(c => c.id === activeModal)?.title}
              </h3>
              <button
                onClick={() => setActiveModal('none')}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="my-5 p-4 bg-slate-50 rounded-xl text-xs text-slate-600 leading-relaxed">
              این بخش توسط پنل مدیریت پیکربندی شده است: {config.cards.find(c => c.id === activeModal)?.subtitle}
            </div>
            <button
              onClick={() => setActiveModal('none')}
              className="w-full bg-[#1e469a] text-white py-2.5 rounded-xl font-bold text-sm"
            >
              بستن
            </button>
          </div>
        </div>
      )}

      {/* Drawer Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-200" dir="rtl">
          <div className="bg-white w-72 h-full p-6 shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-200">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
                  <ShieldCheck className="w-5 h-5 text-blue-600" />
                  <span>منوی سامانه جامع</span>
                </div>
                <button
                  onClick={() => setIsMenuOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-6 space-y-2 text-sm">
                <button
                  onClick={() => {
                    setIsMenuOpen(false);
                    onBackToDashboard();
                  }}
                  className="w-full text-right p-3 rounded-xl hover:bg-slate-50 text-slate-700 font-medium flex items-center justify-between cursor-pointer"
                >
                  <span>داشبورد کاربری</span>
                  <ArrowLeft className="w-4 h-4 text-slate-400" />
                </button>

                {activeCards.map((card) => (
                  <button
                    key={card.id}
                    onClick={() => {
                      setIsMenuOpen(false);
                      handleCardClick(card);
                    }}
                    className="w-full text-right p-3 rounded-xl hover:bg-slate-50 text-slate-700 font-medium flex items-center justify-between cursor-pointer"
                  >
                    <span>{card.title}</span>
                    <ArrowLeft className="w-4 h-4 text-slate-400" />
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                setIsMenuOpen(false);
                onLogout();
              }}
              className="w-full bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>خروج کامل از حساب</span>
            </button>
          </div>
          <div className="flex-1" onClick={() => setIsMenuOpen(false)} />
        </div>
      )}
    </div>
  );
};
