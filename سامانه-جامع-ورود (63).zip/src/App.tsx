import React, { useState, useEffect } from 'react';
import { LoginForm } from './components/LoginForm';
import { UserDashboard } from './components/UserDashboard';
import { ElectronicDossierPage } from './components/ElectronicDossierPage';
import { AdminLogin } from './components/AdminLogin';
import { AdminPanel } from './components/AdminPanel';
import { getSiteConfig, saveSiteConfig } from './utils/appData';
import { SiteConfig } from './types/admin';

export default function App() {
  const [config, setConfig] = useState<SiteConfig>(getSiteConfig());
  
  // User Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<{ username: string; nationalId: string } | null>(null);
  const [currentView, setCurrentView] = useState<'dashboard' | 'dossier'>('dashboard');

  // Admin Authentication & Routing state
  const [isAdminRoute, setIsAdminRoute] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);

  // Check URL on load, popstate and hashchange
  useEffect(() => {
    const checkRoute = () => {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      const search = window.location.search.toLowerCase();
      
      if (
        path.includes('dodozoo') || 
        hash.includes('dodozoo') || 
        search.includes('dodozoo')
      ) {
        setIsAdminRoute(true);
      } else {
        setIsAdminRoute(false);
      }
    };

    checkRoute();
    window.addEventListener('popstate', checkRoute);
    window.addEventListener('hashchange', checkRoute);
    return () => {
      window.removeEventListener('popstate', checkRoute);
      window.removeEventListener('hashchange', checkRoute);
    };
  }, []);

  const handleUpdateConfig = (newConfig: SiteConfig) => {
    setConfig(newConfig);
    saveSiteConfig(newConfig);
  };

  const handleLoginSuccess = (username: string, nationalId: string) => {
    setCurrentUser({ username, nationalId });
    setIsAuthenticated(true);
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
    setCurrentView('dashboard');
  };

  const navigateToAdmin = () => {
    setIsAdminRoute(true);
    window.history.pushState({}, '', '#dodozoo');
  };

  const navigateToSite = () => {
    setIsAdminRoute(false);
    window.history.pushState({}, '', '#/');
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans selection:bg-blue-100 selection:text-blue-900">
      {/* Main Content Area */}
      <main className="flex-1 flex flex-col justify-center items-center py-6 px-3 sm:px-4">
        {isAdminRoute ? (
          /* Admin View (Accessed strictly via URL koonik.ir/dodozoo) */
          isAdminAuthenticated ? (
            <AdminPanel
              config={config}
              onUpdateConfig={handleUpdateConfig}
              onLogoutAdmin={() => setIsAdminAuthenticated(false)}
              onViewLiveSite={navigateToSite}
            />
          ) : (
            <AdminLogin
              onSuccess={() => setIsAdminAuthenticated(true)}
              onExitToSite={navigateToSite}
            />
          )
        ) : (
          /* User Site View */
          isAuthenticated && currentUser ? (
            currentView === 'dossier' ? (
              <ElectronicDossierPage
                config={config}
                username={currentUser.username}
                nationalId={currentUser.nationalId}
                onBackToDashboard={() => setCurrentView('dashboard')}
                onLogout={handleLogout}
                onOpenAdmin={navigateToAdmin}
                onUpdateConfig={handleUpdateConfig}
              />
            ) : (
              <UserDashboard
                config={config}
                username={currentUser.username}
                nationalId={currentUser.nationalId}
                onLogout={handleLogout}
                onOpenElectronicDossier={() => setCurrentView('dossier')}
              />
            )
          ) : (
            <LoginForm 
              config={config}
              onSuccessLogin={handleLoginSuccess}
            />
          )
        )}
      </main>
    </div>
  );
}
