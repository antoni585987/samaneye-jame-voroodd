import { SiteConfig, Announcement } from '../types/admin';

export const DEFAULT_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'دستورالعمل مهم حضور در جلسه آزمون سراسری',
    content: 'داوطلبان گرامی، همراه داشتن پرینت کارت ورود به جلسه و اصل کارت ملی یا شناسنامه عکس‌دار در روز برگزاری آزمون الزامی است. ورود هرگونه وسایل الکترونیکی مانند تلفن همراه، ساعت هوشمند و ماشین حساب اکیداً ممنوع می‌باشد.',
    date: '۱۴۰۳/۰۴/۱۵',
    priority: 'urgent',
    isActive: true,
  },
  {
    id: 'ann-2',
    title: 'اطلاعیه زمان‌بندی تغییر حوزه امتحانی',
    content: 'مهلت ثبت درخواست تغییر حوزه امتحانی تا ۴۸ ساعت قبل از روز برگزاری آزمون در بخش پرونده الکترونیک فعال است.',
    date: '۱۴۰۳/۰۴/۱۲',
    priority: 'important',
    isActive: true,
  },
  {
    id: 'ann-3',
    title: 'راهنمای دریافت کارنامه و سوابق تحصیلی',
    content: 'کارنامه آزمون نهایی و تراز سوابق تحصیلی پس از پایان فرآیند تصحیح اوراق از طریق سامانه پرونده الکترونیک قابل مشاهده و دریافت می‌باشد.',
    date: '۱۴۰۳/۰۴/۱۰',
    priority: 'info',
    isActive: true,
  }
];

export const DEFAULT_SITE_CONFIG: SiteConfig = {
  siteTitle: 'سراسری و دانشجو-معلم',
  siteSubtitle: 'مدیریت آزمون سراسری و دانشجو-معلم و فرایندهای مرتبط',
  badgeText: 'سراسری و دانشجو معلم',
  version: '۴.۲.۰',
  securityNotice: 'اتصال امن و رمزنگاری شده برقرار است',
  
  allowedUsers: [
    {
      id: '1',
      username: 'امیرحسین صادقیان',
      nationalId: '2960931394',
      role: 'کاربر ارشد',
      status: 'active',
    }
  ],

  cards: [
    {
      id: 'card-1',
      title: 'ثبت نام در آزمون',
      subtitle: 'ثبت نام در آزمون سراسری و دانشجو-معلم',
      iconType: 'user-plus',
      buttonText: 'ورود به بخش',
      isActive: true,
      order: 1,
    },
    {
      id: 'card-2',
      title: 'کارت ورود به جلسه',
      subtitle: 'دریافت کارت ورود به جلسه آزمون',
      iconType: 'id-card',
      buttonText: 'ورود به بخش',
      isActive: true,
      order: 2,
    },
    {
      id: 'card-3',
      title: 'تغییر حوزه آزمون سراسری',
      subtitle: 'رشته تجربی',
      iconType: 'map-pin',
      buttonText: 'ورود به بخش',
      isActive: true,
      order: 3,
    },
    {
      id: 'card-4',
      title: 'کارنامه آزمون نهایی',
      subtitle: 'مشاهده کارنامه آزمون نهایی',
      iconType: 'file-text',
      buttonText: 'ورود به بخش',
      isActive: true,
      order: 4,
    },
    {
      id: 'card-5',
      title: 'مشاهده رتبه آزمون سراسری',
      subtitle: 'نتایج آزمون سراسری',
      iconType: 'award',
      buttonText: 'ورود به بخش',
      isActive: true,
      order: 5,
    },
  ],

  announcements: DEFAULT_ANNOUNCEMENTS,

  registrationStatus: 'تایید نهایی و قطعی',
  studyGroup: 'علوم تجربی و فرهنگیان',
  fileNumber: '۹۸۴۲۱۵۳۷',

  examDate: 'پنج‌شنبه - نوبت صبح',
  arrivalTime: '۰۷:۳۰ صبح',
  examVenue: 'دانشکده فنی و مهندسی',
  examHall: 'سالن شماره ۲',
  examCardImage: null,
  candidatePhoto: null,

  venues: [
    { id: 'v1', city: 'تهران', name: 'تهران - منطقه ۵ (دانشکده مهندسی)', code: 'TEH-105' },
    { id: 'v2', city: 'تهران', name: 'تهران - منطقه ۲ (دانشگاه صنعتی شریف)', code: 'TEH-102' },
    { id: 'v3', city: 'اصفهان', name: 'اصفهان - مرکز (دانشگاه اصفهان)', code: 'ISF-201' },
    { id: 'v4', city: 'شیراز', name: 'شیراز - ناحیه ۱ (دانشگاه شیراز)', code: 'SHR-301' },
    { id: 'v5', city: 'مشهد', name: 'مشهد - ناحیه ۴ (دانشگاه فردوسی)', code: 'MSH-404' },
    { id: 'v6', city: 'تبریز', name: 'تبریز - ناحیه ۲ (دانشگاه تبریز)', code: 'TBZ-502' },
  ],

  finalGPA: '۱۹.۷۸',
  subjectGrades: [
    { subject: 'زیست‌شناسی ۳', grade: '۲۰.۰۰' },
    { subject: 'شیمی ۳', grade: '۱۹.۷۵' },
    { subject: 'فیزیک ۳', grade: '۱۹.۵۰' },
    { subject: 'ریاضی ۳', grade: '۱۹.۵۰' },
    { subject: 'فارسی ۳', grade: '۲۰.۰۰' },
  ],

  quotaRank: '۴۱۲',
  quotaTitle: 'رتبه در سهمیه (منطقه ۱)',
  nationalRank: '۱,۰۸۵',
  totalScore: '۱۱,۴۹۰',
  qualificationStatus: 'مجاز در تمامی دوره‌ها',
  farhangianStatus: 'مجاز و واجد شرایط مصاحبه',
};

const STORAGE_KEY = 'koonik_site_config_v1';

export function getSiteConfig(): SiteConfig {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return { 
        ...DEFAULT_SITE_CONFIG, 
        ...parsed,
        venues: parsed.venues && parsed.venues.length > 0 ? parsed.venues : DEFAULT_SITE_CONFIG.venues,
        announcements: parsed.announcements && parsed.announcements.length > 0 ? parsed.announcements : DEFAULT_SITE_CONFIG.announcements,
      };
    }
  } catch (err) {
    console.error('Error loading config:', err);
  }
  return DEFAULT_SITE_CONFIG;
}

export function saveSiteConfig(config: SiteConfig): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch (err) {
    console.error('Error saving config:', err);
  }
}

export function resetSiteConfig(): SiteConfig {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (err) {
    console.error('Error resetting config:', err);
  }
  return DEFAULT_SITE_CONFIG;
}
