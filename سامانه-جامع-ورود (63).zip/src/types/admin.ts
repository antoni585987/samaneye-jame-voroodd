export interface AllowedUser {
  id: string;
  username: string;
  nationalId: string;
  role: string;
  status: 'active' | 'inactive';
}

export interface DossierCard {
  id: string;
  title: string;
  subtitle: string;
  iconType: 'user-plus' | 'id-card' | 'file-text' | 'award' | 'school' | 'map-pin' | 'calendar' | 'custom';
  buttonText: string;
  isActive: boolean;
  order: number;
}

export interface ExamVenue {
  id: string;
  name: string;
  code: string;
  city: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
  priority: 'urgent' | 'important' | 'info';
  isActive: boolean;
}

export interface SiteConfig {
  siteTitle: string;
  siteSubtitle: string;
  badgeText: string;
  version: string;
  securityNotice: string;
  allowedUsers: AllowedUser[];
  cards: DossierCard[];
  
  // Announcements
  announcements: Announcement[];

  // Registration data
  registrationStatus: string;
  studyGroup: string;
  fileNumber: string;

  // Exam card data
  examDate: string;
  arrivalTime: string;
  examVenue: string;
  examHall: string;
  examCardImage: string | null; // Base64 data URL
  candidatePhoto: string | null; // Base64 data URL

  // Custom selectable venues
  venues: ExamVenue[];

  // Report card data
  finalGPA: string;
  subjectGrades: { subject: string; grade: string }[];

  // Rank data
  quotaRank: string;
  quotaTitle: string;
  nationalRank: string;
  totalScore: string;
  qualificationStatus: string;
  farhangianStatus: string;
}
